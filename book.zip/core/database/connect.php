<?php
$connection = mysql_connect("localhost","root","") or die("could not connect");
mysql_select_db("book",$connection);
?>